<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Seepossible\Blog\Model\Data;

use Seepossible\Blog\Api\Data\BlogInterface;

class Blog extends \Magento\Framework\Api\AbstractExtensibleObject implements BlogInterface
{

    /**
     * Get blog_id
     * @return string|null
     */
    public function getBlogId()
    {
        return $this->_get(self::BLOG_ID);
    }

    /**
     * Set blog_id
     * @param string $blogId
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setBlogId($blogId)
    {
        return $this->setData(self::BLOG_ID, $blogId);
    }

    /**
     * Get title
     * @return string|null
     */
    public function getTitle()
    {
        return $this->_get(self::TITLE);
    }

    /**
     * Set title
     * @param string $title
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setTitle($title)
    {
        return $this->setData(self::TITLE, $title);
    }

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Seepossible\Blog\Api\Data\BlogExtensionInterface|null
     */
    public function getExtensionAttributes()
    {
        return $this->_getExtensionAttributes();
    }

    /**
     * Set an extension attributes object.
     * @param \Seepossible\Blog\Api\Data\BlogExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Seepossible\Blog\Api\Data\BlogExtensionInterface $extensionAttributes
    ) {
        return $this->_setExtensionAttributes($extensionAttributes);
    }

    /**
     * Get details
     * @return string|null
     */
    public function getDetails()
    {
        return $this->_get(self::DETAILS);
    }

    /**
     * Set details
     * @param string $details
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setDetails($details)
    {
        return $this->setData(self::DETAILS, $details);
    }

    /**
     * Get picture
     * @return string|null
     */
    public function getPicture()
    {
        return $this->_get(self::PICTURE);
    }

    /**
     * Set picture
     * @param string $picture
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setPicture($picture)
    {
        return $this->setData(self::PICTURE, $picture);
    }

    /**
     * Get is_active
     * @return string|null
     */
    public function getIsActive()
    {
        return $this->_get(self::IS_ACTIVE);
    }

    /**
     * Set is_active
     * @param string $isActive
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setIsActive($isActive)
    {
        return $this->setData(self::IS_ACTIVE, $isActive);
    }

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt()
    {
        return $this->_get(self::CREATED_AT);
    }

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt()
    {
        return $this->_get(self::UPDATED_AT);
    }

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }
}

