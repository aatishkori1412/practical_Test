<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Seepossible\Blog\Model;

use Magento\Framework\Api\DataObjectHelper;
use Seepossible\Blog\Api\Data\BlogInterface;
use Seepossible\Blog\Api\Data\BlogInterfaceFactory;

class Blog extends \Magento\Framework\Model\AbstractModel
{

    protected $dataObjectHelper;

    protected $_eventPrefix = 'seepossible_blog_blog';
    protected $blogDataFactory;


    /**
     * @param \Magento\Framework\Model\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param BlogInterfaceFactory $blogDataFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param \Seepossible\Blog\Model\ResourceModel\Blog $resource
     * @param \Seepossible\Blog\Model\ResourceModel\Blog\Collection $resourceCollection
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        BlogInterfaceFactory $blogDataFactory,
        DataObjectHelper $dataObjectHelper,
        \Seepossible\Blog\Model\ResourceModel\Blog $resource,
        \Seepossible\Blog\Model\ResourceModel\Blog\Collection $resourceCollection,
        array $data = []
    ) {
        $this->blogDataFactory = $blogDataFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        parent::__construct($context, $registry, $resource, $resourceCollection, $data);
    }

    /**
     * Retrieve blog model with blog data
     * @return BlogInterface
     */
    public function getDataModel()
    {
        $blogData = $this->getData();
        
        $blogDataObject = $this->blogDataFactory->create();
        $this->dataObjectHelper->populateWithArray(
            $blogDataObject,
            $blogData,
            BlogInterface::class
        );
        
        return $blogDataObject;
    }
}

