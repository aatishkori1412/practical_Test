<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Seepossible\Blog\Block\Index;
use Magento\Cms\Model\Template\FilterProvider;
use Magento\Framework\ObjectManagerInterface;
use Seepossible\Blog\Api\BlogGroupRepositoryInterface;
use Seepossible\Blog\Helper\Data as HelperData;
use Seepossible\Blog\Model\ResourceModel\Blog\CollectionFactory;

class Index extends \Magento\Framework\View\Element\Template
{

    protected $objectManager;

    /**
     * Constructor
     *
     * @param \Magento\Framework\View\Element\Template\Context  $context
     * @param array $data
     */

    /**
     * @var CollectionFactory
     */
    protected $blogCollectionFactory;


    /**
     * Index constructor.
     *
     * @param Template\Context $context
     * @param CollectionFactory $blogCollectionFactory
     */
    public function __construct(
        CollectionFactory $blogCollectionFactory,
        \Magento\Framework\View\Element\Template\Context $context,
        ObjectManagerInterface $objectManager,
        array $data = []
    ) {
        $this->blogCollectionFactory = $blogCollectionFactory;
        $this->objectManager = $objectManager;
        parent::__construct($context, $data);
    }

    public function getMediaUrl(){

        $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
            ->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

        return $media_dir;
    }

    public function getBlogCollection()
    {

        $blogCollection = $this->blogCollectionFactory->create();
        return $blogCollection;
    }


}

