<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Seepossible\Blog\Api\Data;

interface BlogInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const IS_ACTIVE = 'is_active';
    const CREATED_AT = 'created_at';
    const TITLE = 'title';
    const PICTURE = 'picture';
    const BLOG_ID = 'blog_id';
    const DETAILS = 'details';
    const UPDATED_AT = 'updated_at';

    /**
     * Get blog_id
     * @return string|null
     */
    public function getBlogId();

    /**
     * Set blog_id
     * @param string $blogId
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setBlogId($blogId);

    /**
     * Get title
     * @return string|null
     */
    public function getTitle();

    /**
     * Set title
     * @param string $title
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setTitle($title);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Seepossible\Blog\Api\Data\BlogExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Seepossible\Blog\Api\Data\BlogExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Seepossible\Blog\Api\Data\BlogExtensionInterface $extensionAttributes
    );

    /**
     * Get details
     * @return string|null
     */
    public function getDetails();

    /**
     * Set details
     * @param string $details
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setDetails($details);

    /**
     * Get picture
     * @return string|null
     */
    public function getPicture();

    /**
     * Set picture
     * @param string $picture
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setPicture($picture);

    /**
     * Get is_active
     * @return string|null
     */
    public function getIsActive();

    /**
     * Set is_active
     * @param string $isActive
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setIsActive($isActive);

    /**
     * Get created_at
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set created_at
     * @param string $createdAt
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setCreatedAt($createdAt);

    /**
     * Get updated_at
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set updated_at
     * @param string $updatedAt
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    public function setUpdatedAt($updatedAt);
}

