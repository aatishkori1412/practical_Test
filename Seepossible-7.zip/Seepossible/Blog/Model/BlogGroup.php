<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Model;

use Magento\Framework\Model\AbstractModel;
use Seepossible\Blog\Api\Data\BlogGroupInterface;
use Seepossible\Blog\Model\ResourceModel\BlogGroup as BlogGroupResourceModel;

class BlogGroup extends AbstractModel implements BlogGroupInterface
{
    /**
     * @return void
     */
    public function _construct()
    {
        $this->_init(BlogGroupResourceModel::class);
    }

    /**
     * Get bloggroup_id
     * @return string
     */
    public function getBloggroupId()
    {
        return $this->getData(self::BLOGGROUP_ID);
    }

    /**
     * Set bloggroup_id
     * @param string $bloggroupId
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    public function setBloggroupId($bloggroupId)
    {
        return $this->setData(self::BLOGGROUP_ID, $bloggroupId);
    }

    /**
     * Get groupname
     * @return string
     */
    public function getGroupname()
    {
        return $this->getData(self::GROUPNAME);
    }

    /**
     * Set groupname
     * @param string $groupname
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    public function setGroupname($groupname)
    {
        return $this->setData(self::GROUPNAME, $groupname);
    }

    /**
     * Get groupcode
     * @return string
     */
    public function getGroupcode()
    {
        return $this->getData(self::GROUPCODE);
    }

    /**
     * Set groupcode
     * @param string $groupcode
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    public function setGroupcode($groupcode)
    {
        return $this->setData(self::GROUPCODE, $groupcode);
    }

    /**
     * Get icon
     * @return string
     */
    public function getIcon()
    {
        return $this->getData(self::ICON);
    }

    /**
     * Set icon
     * @param string $icon
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    public function setIcon($icon)
    {
        return $this->setData(self::ICON, $icon);
    }

    /**
     * Get width
     * @return string
     */
    public function getWidth()
    {
        return $this->getData(self::WIDTH);
    }

    /**
     * Set width
     * @param string $width
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    public function setWidth($width)
    {
        return $this->setData(self::WIDTH, $width);
    }

    /**
     * Get blogids
     * @return string
     */
    public function getBlogids()
    {
        return $this->getData(self::BLOGIDS);
    }

    /**
     * Set blogids
     * @param string $blogids
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    public function setBlogids($blogids)
    {
        return $this->setData(self::BLOGIDS, $blogids);
    }

    /**
     * Get status
     * @return string
     */
    public function getStatus()
    {
        return $this->getData(self::STATUS);
    }

    /**
     * Set status
     * @param string $status
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    public function setStatus($status)
    {
        return $this->setData(self::STATUS, $status);
    }
}
