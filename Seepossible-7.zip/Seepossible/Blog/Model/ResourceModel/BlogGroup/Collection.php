<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Model\ResourceModel\BlogGroup;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;
use Seepossible\Blog\Model\BlogGroup as BlogGroupModel;
use Seepossible\Blog\Model\ResourceModel\BlogGroup as BlogGroupResourceModel;

class Collection extends AbstractCollection
{
    public $_idFieldName = 'bloggroup_id';
   
    /**
     * Define resource model
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init(
            BlogGroupModel::class,
            BlogGroupResourceModel::class
        );
    }

    /**
     * Retrieve option array
     *
     * @return array
     */
    public function toOptionArray()
    {
        return parent::_toOptionArray('bloggroup_id', 'groupname');
    }
}
