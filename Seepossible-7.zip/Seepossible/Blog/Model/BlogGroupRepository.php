<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Model;

use Seepossible\Blog\Model\ResourceModel\BlogGroup as ResourceBlogGroup;
use Magento\Framework\Exception\CouldNotSaveException;
use Seepossible\Blog\Api\Data\BlogGroupSearchResultsInterfaceFactory;
use Magento\Framework\Api\DataObjectHelper;
use Seepossible\Blog\Api\Data\BlogGroupInterfaceFactory;
use Seepossible\Blog\Model\ResourceModel\BlogGroup\CollectionFactory as BlogGroupCollectionFactory;
use Magento\Framework\Reflection\DataObjectProcessor;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Api\SortOrder;
use Seepossible\Blog\Api\BlogGroupRepositoryInterface;

class BlogGroupRepository implements BlogGroupRepositoryInterface
{

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var \Seepossible\Blog\Model\ResourceModel\BlogGroup
     */
    private $resource;

    /**
     * @var \Seepossible\Blog\Api\Data\BlogGroupFactory
     */
    private $BlogGroupFactory;

    /**
     * @var \Seepossible\Blog\Api\Data\BlogGroupInterfaceFactory
     */
    private $dataBlogGroupFactory;

    /**
     * @var \Seepossible\Blog\Model\ResourceModel\BlogGroup\CollectionFactory
     */
    private $BlogGroupCollectionFactory;

    /**
     * @var \Magento\Framework\Reflection\DataObjectProcessor
     */
    private $dataObjectProcessor;

    /**
     * @var \Magento\Framework\Api\DataObjectHelper
     */
    private $dataObjectHelper;

    /**
     * @var \Seepossible\Blog\Api\Data\BlogGroupSearchResultsInterfaceFactory
     */
    private $searchResultsFactory;

    /**
     * @param ResourceBlogGroup $resource
     * @param BlogGroupFactory $blogGroupFactory
     * @param BlogGroupInterfaceFactory $dataBlogGroupFactory
     * @param BlogGroupCollectionFactory $blogGroupCollectionFactory
     * @param BlogGroupSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param StoreManagerInterface $storeManager
     */
    public function __construct(
        ResourceBlogGroup $resource,
        BlogGroupFactory $blogGroupFactory,
        BlogGroupInterfaceFactory $dataBlogGroupFactory,
        BlogGroupCollectionFactory $blogGroupCollectionFactory,
        BlogGroupSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        StoreManagerInterface $storeManager
    ) {
        $this->resource = $resource;
        $this->blogGroupFactory = $blogGroupFactory;
        $this->blogGroupCollectionFactory = $blogGroupCollectionFactory;
        $this->searchResultsFactory = $searchResultsFactory;
        $this->dataObjectHelper = $dataObjectHelper;
        $this->dataBlogGroupFactory = $dataBlogGroupFactory;
        $this->dataObjectProcessor = $dataObjectProcessor;
        $this->storeManager = $storeManager;
    }

    /**
     * {@inheritdoc}
     */
    public function save(
        \Seepossible\Blog\Api\Data\BlogGroupInterface $blogGroup
    ) {
        try {
            $blogGroup->getResource()->save($blogGroup);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__(
                'Could not save the blogGroup: %1',
                $exception->getMessage()
            ));
        }
        return $blogGroup;
    }

    /**
     * {@inheritdoc}
     */
    public function getById($blogGroupId)
    {
        $blogGroup = $this->blogGroupFactory->create();
        $blogGroup->getResource()->load($blogGroup, $blogGroupId);
        if (!$blogGroup->getId()) {
            throw new NoSuchEntityException(__('BlogGroup with id "%1" does not exist.', $blogGroupId));
        }
        return $blogGroup;
    }

    /**
     * {@inheritdoc}
     */
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $criteria
    ) {
        $collection = $this->blogGroupCollectionFactory->create();
        foreach ($criteria->getFilterGroups() as $filterGroup) {
            foreach ($filterGroup->getFilters() as $filter) {
                if ($filter->getField() === 'store_id') {
                    $collection->addStoreFilter($filter->getValue(), false);
                    continue;
                }
                $condition = $filter->getConditionType() ?: 'eq';
                $collection->addFieldToFilter($filter->getField(), [$condition => $filter->getValue()]);
            }
        }
        
        $sortOrders = $criteria->getSortOrders();
        if ($sortOrders) {
            /** @var SortOrder $sortOrder */
            foreach ($sortOrders as $sortOrder) {
                $collection->addOrder(
                    $sortOrder->getField(),
                    ($sortOrder->getDirection() == SortOrder::SORT_ASC) ? 'ASC' : 'DESC'
                );
            }
        }
        $collection->setCurPage($criteria->getCurrentPage());
        $collection->setPageSize($criteria->getPageSize());
        
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($criteria);
        $searchResults->setTotalCount($collection->getSize());
        $searchResults->setItems($collection->getItems());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(
        \Seepossible\Blog\Api\Data\BlogGroupInterface $blogGroup
    ) {
        try {
            $blogGroup->getResource()->delete($blogGroup);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__(
                'Could not delete the BlogGroup: %1',
                $exception->getMessage()
            ));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($blogGroupId)
    {
        return $this->delete($this->getById($blogGroupId));
    }
}
