<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Model\Config;

class DefaultConfig
{
    /**
     * Is enabled module config path
     */
    const CONFIG_PATH_IS_ENABLE = 'blogtab/general/enable';

    /**
     * Is enable show group config path
     */
    const CONFIG_PATH_IS_SHOW_GROUP = 'blogtab/design/showgroup';

    /**
     * Is enable show group title
     */
    const CONFIG_PATH_IS_SHOW_GROUP_TITLE = 'blogtab/design/showgrouptitle';

    /**
     * Blog page type config path
     */
    const CONFIG_PATH_PAGE_TYPE = 'blogtab/design/page_type';

    /**
     * Blog url config path
     */
    const BLOG_URL_CONFIG_PATH = 'blogtab/seo/blog_url';
}
