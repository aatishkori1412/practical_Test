<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Controller\Adminhtml\Blog;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\Json;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultInterface;
use Seepossible\Blog\Model\Blog as BlogModel;

class InlineEdit extends Action
{
    /**
     * @var JsonFactory
     */
    private $jsonFactory;

    /**
     * @var BlogModel
     */
    private $blogModel;

    /**
     * InlineEdit constructor.
     *
     * @param Context $context
     * @param JsonFactory $jsonFactory
     * @param BlogModel $blogModel
     */
    public function __construct(
        Context $context,
        JsonFactory $jsonFactory,
        BlogModel $blogModel
    ) {
        parent::__construct($context);
        $this->blogModel = $blogModel;
        $this->jsonFactory = $jsonFactory;
    }

    /**
     * {@inheritdoc}
     */
    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Seepossible_Blog::Blog');
    }

    /**
     * Inline edit action
     *
     * @return ResultInterface
     */
    public function execute()
    {
        /** @var Json $resultJson */
        $resultJson = $this->jsonFactory->create();
        $error = false;
        $messages = [];
        
        if ($this->getRequest()->getParam('isAjax')) {
            $postItems = $this->getRequest()->getParam('items', []);
            if (empty($postItems)) {
                $messages[] = __('Please correct the data sent.');
                $error = true;
            } else {
                foreach (array_keys($postItems) as $modelid) {
                    /** @var \Magento\Cms\Model\Block $block */
                    $model = $this->blogModel->load($modelid);
                    try {
                        $model->setData(array_merge($model->getData(), $postItems[$modelid]));
                        $model->save();
                    } catch (\Exception $e) {
                        $messages[] = "[Blog ID: {$modelid}]  {$e->getMessage()}";
                        $error = true;
                    }
                }
            }
        }
        
        return $resultJson->setData([
            'messages' => $messages,
            'error' => $error
        ]);
    }
}
