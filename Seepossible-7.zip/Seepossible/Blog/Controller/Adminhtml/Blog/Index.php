<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Controller\Adminhtml\Blog;

use Magento\Backend\App\Action;

class Index extends Action
{

    private $resultPageFactory;

    /**
     * Constructor
     *
     * @param \Magento\Backend\App\Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Seepossible_Blog::Blog');
    }

    /**
     * Index action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $resultPage = $this->resultPageFactory->create();
            $resultPage->getConfig()->getTitle()->prepend(__("BLOG"));
            return $resultPage;
    }
}
