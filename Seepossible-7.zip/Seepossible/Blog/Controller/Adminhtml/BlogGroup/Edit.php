<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Controller\Adminhtml\BlogGroup;

use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Registry;
use Magento\Framework\View\Result\PageFactory;
use Seepossible\Blog\Controller\Adminhtml\BlogGroup;
use Seepossible\Blog\Model\BlogGroup as BlogGroupModel;

class Edit extends BlogGroup
{

    /**
     * @var PageFactory
     */
    private $resultPageFactory;

    /**
     * @var BlogGroupModel
     */
    private $blogGroupModel;

    /**
     * Edit constructor.
     *
     * @param Context $context
     * @param Registry $coreRegistry
     * @param PageFactory $resultPageFactory
     * @param BlogGroupModel $blogGroupModel
     */
    public function __construct(
        Context $context,
        Registry $coreRegistry,
        PageFactory $resultPageFactory,
        BlogGroupModel $blogGroupModel
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->blogGroupModel = $blogGroupModel;
        $this->coreRegistry = $coreRegistry;
        parent::__construct($context, $coreRegistry);
    }

    /**
     * {@inheritdoc}
     */
    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Seepossible_Blog::BlogGroup');
    }

    /**
     * Edit action
     *
     * @return ResultInterface
     */
    public function execute()
    {
        // 1. Get ID and create model
        $id = $this->getRequest()->getParam('bloggroup_id');
        $model = $this->blogGroupModel;
        
        // 2. Initial checking
        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addErrorMessage(__('This BLOGgroup no longer exists.'));
                /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();
                return $resultRedirect->setPath('*/*/');
            }
        }
        $this->coreRegistry->register('possible_blog_bloggroup', $model);
        
        // 5. Build edit form
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();




        $this->initPage($resultPage)->addBreadcrumb(
            $id ? __('Edit Bloggroup') : __('New BLOGGroup'),
            $id ? __('Edit Bloggroup') : __('New BLOGGroup')
        );
        $resultPage->getConfig()->getTitle()->prepend(__('BLOGgroups'));
        $resultPage->getConfig()->getTitle()->prepend($model->getId() ? $model->getTitle() : __('New BLOGGroup'));
        return $resultPage;
    }
}
