<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Controller\Adminhtml\BlogGroup;

use Magento\Backend\App\Action;
use Magento\Backend\Model\View\Result\Redirect;
use Magento\Framework\App\Request\DataPersistorInterface;
use Magento\Framework\Controller\ResultInterface;
use Magento\Framework\Exception\LocalizedException;
use Seepossible\Blog\Model\BlogGroup;

class Save extends Action
{

    /**
     * @var DataPersistorInterface
     */
    private $dataPersistor;

    /**
     * @var BlogGroup
     */
    private $blogModel;

    /**
     * Save constructor.
     *
     * @param Action\Context $context
     * @param BlogGroup $blogModel
     * @param DataPersistorInterface $dataPersistor
     */
    public function __construct(
        Action\Context $context,
        BlogGroup $blogModel,
        DataPersistorInterface $dataPersistor
    ) {
        $this->dataPersistor = $dataPersistor;
        $this->blogModel = $blogModel;
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    public function _isAllowed()
    {
        return $this->_authorization->isAllowed('Seepossible_Blog::BlogGroup');
    }

    /**
     * Save action
     *
     * @return ResultInterface
     */
    public function execute()
    {
        /** @var Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        $data = $this->getRequest()->getPostValue();

        if ($data) {
            $id = $this->getRequest()->getParam('bloggroup_id');
        
            $model = $this->blogModel->load($id);
            if (!$model->getId() && $id) {
                $this->messageManager->addErrorMessage(__('This BLOGgroup no longer exists.'));
                return $resultRedirect->setPath('*/*/');
            }
            
            $data = $this->_filterBlogGroupData($data);
            $cGroup = $data['customer_group'];
            if (isset($cGroup)) {
                $customerGroup = implode(',', $data['customer_group']);
                $data['customer_group'] = $customerGroup;
            }
            $stores = $data['storeview'];
            if (isset($stores)) {
                $store = implode(',', $data['storeview']);
                $data['storeview'] = $store;
            }
            
            $model->setData($data);
        
            try {
                $model->save();
                $this->messageManager->addSuccessMessage(__('You saved the BLOGgroup.'));
                $this->dataPersistor->clear('possible_blog_bloggroup');
        
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['bloggroup_id' => $model->getId()]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (LocalizedException $e) {
                $this->messageManager->addErrorMessage($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager
                ->addExceptionMessage($e, __('Something went wrong while saving the Bloggroup.'));
            }
        
            $this->dataPersistor->set('possible_blog_bloggroup', $data);
            return $resultRedirect->setPath(
                '*/*/edit',
                [
                    'bloggroup_id' => $this->getRequest()->getParam('bloggroup_id')
                ]
            );
        }
        return $resultRedirect->setPath('*/*/');
    }

    public function _filterBlogGroupData(array $rawData)
    {
        $data = $rawData;
        if (isset($data['icon'][0]['name'])) {
            $data['icon'] = $data['icon'][0]['name'];
        } else {
            $data['icon'] = null;
        }
        return $data;
    }
}
