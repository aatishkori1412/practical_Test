<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Plugin\Magento\Backend\Model\Menu;

class Item
{
    /**
     * @param $subject
     * @param $result
     * @return string
     */
    public function afterGetUrl($subject, $result)
    {
        $menuId = $subject->getId();
        
        if ($menuId == 'Seepossible_Blog::blog_user_guid') {
            $result = 'https://marketplace.magento.com/media/catalog/product/possible-module-blog-2-0-1-ce/user_guides.pdf';
        } elseif ($menuId == 'Seepossible_Blog::other_modules') {
            $result = 'http://seepossible.com/blog/modules';
        }
        
        return $result;
    }
}
