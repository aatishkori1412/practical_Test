var config = {
    paths: {
        owlcarousel: "Seepossible_Blog/js/owl.carousel"
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};