<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

interface BlogGroupRepositoryInterface
{

    /**
     * Save BlogGroup
     * @param \Seepossible\Blog\Api\Data\BlogGroupInterface $blogGroup
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    
    public function save(
        \Seepossible\Blog\Api\Data\BlogGroupInterface $blogGroup
    );

    /**
     * Retrieve BlogGroup
     * @param string $bloggroupId
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    
    public function getById($bloggroupId);

    /**
     * Retrieve BlogGroup matching the specified criteria.
     * @param \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
     * @return \Seepossible\Blog\Api\Data\BlogGroupSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    
    public function getList(
        \Magento\Framework\Api\SearchCriteriaInterface $searchCriteria
    );

    /**
     * Delete BlogGroup
     * @param \Seepossible\Blog\Api\Data\BlogGroupInterface $blogGroup
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    
    public function delete(
        \Seepossible\Blog\Api\Data\BlogGroupInterface $blogGroup
    );

    /**
     * Delete BlogGroup by ID
     * @param string $bloggroupId
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    
    public function deleteById($bloggroupId);
}
