<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Api\Data;

interface BlogGroupInterface
{

    const GROUPNAME = 'groupname';
    const BLOGIDS = 'blogids';
    const BLOGGROUP_ID = 'bloggroup_id';
    const ICON = 'icon';
    const STATUS = 'status';
    const GROUPCODE = 'groupcode';
    const WIDTH = 'width';

    /**
     * Get bloggroup_id
     * @return string|null
     */
    
    public function getBloggroupId();

    /**
     * Set bloggroup_id
     * @param string $bloggroup_id
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    
    public function setBloggroupId($bloggroupId);

    /**
     * Get groupname
     * @return string|null
     */
    
    public function getGroupname();

    /**
     * Set groupname
     * @param string $groupname
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    
    public function setGroupname($groupname);

    /**
     * Get groupcode
     * @return string|null
     */
    
    public function getGroupcode();

    /**
     * Set groupcode
     * @param string $groupcode
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    
    public function setGroupcode($groupcode);

    /**
     * Get icon
     * @return string|null
     */
    
    public function getIcon();

    /**
     * Set icon
     * @param string $icon
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    
    public function setIcon($icon);

    /**
     * Get width
     * @return string|null
     */
    
    public function getWidth();

    /**
     * Set width
     * @param string $width
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    
    public function setWidth($width);

    /**
     * Get blogids
     * @return string|null
     */
    
    public function getBlogids();

    /**
     * Set blogids
     * @param string $blogids
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    
    public function setBlogids($blogids);

    /**
     * Get status
     * @return string|null
     */
    
    public function getStatus();

    /**
     * Set status
     * @param string $status
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */
    
    public function setStatus($status);
}
