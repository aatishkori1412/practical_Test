<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Api\Data;

use Magento\Framework\Api\SearchResultsInterface;

interface BlogSearchResultsInterface extends SearchResultsInterface
{
    
    /**
     * Get Blog list.
     * @return \Seepossible\Blog\Api\Data\BlogInterface[]
     */
    
    public function getItems();

    /**
     * Set title list.
     * @param \Seepossible\Blog\Api\Data\BlogInterface[] $items
     * @return $this
     */
    
    public function setItems(array $items);
}
