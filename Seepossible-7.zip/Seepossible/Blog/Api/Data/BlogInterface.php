<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Api\Data;

interface BlogInterface
{

    const TITLE = 'title';
    const SORTORDER = 'sortorder';
    const BLOG_ID = 'blog_id';
    const CONTENT = 'content';
    const STATUS = 'status';
    const ICON = 'icon';

    /**
     * Get blog_id
     * @return string|null
     */
    
    public function getBlogId();

    /**
     * Set blog_id
     * @param string $blog_id
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    
    public function setBlogId($blogId);

    /**
     * Get title
     * @return string|null
     */
    
    public function getTitle();

    /**
     * Set title
     * @param string $title
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    
    public function setTitle($title);

    /**
     * Get content
     * @return string|null
     */
    
    public function getContent();

    /**
     * Set content
     * @param string $content
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    
    public function setContent($content);

    /**
     * Get sortorder
     * @return string|null
     */
    
    public function getSortorder();

    /**
     * Set sortorder
     * @param string $sortorder
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    
    public function setSortorder($sortorder);

    /**
     * Get status
     * @return string|null
     */
    
    public function getStatus();

    /**
     * Set status
     * @param string $status
     * @return \Seepossible\Blog\Api\Data\BlogInterface
     */
    
    public function setStatus($status);


    /**
     * Get icon
     * @return string|null
     */

    public function getIcon();

    /**
     * Set icon
     * @param string $icon
     * @return \Seepossible\Blog\Api\Data\BlogGroupInterface
     */

    public function setIcon($icon);

}
