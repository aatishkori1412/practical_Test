<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Ui\Component\Listing\Column;

use Magento\Framework\Data\OptionSourceInterface;
use Seepossible\Blog\Model\ResourceModel\Blog\CollectionFactory;

class BlogIds implements OptionSourceInterface
{
    /**
     * @var CollectionFactory
     */
    private $blogCollection;

    /**
     * BlogIds constructor.
     *
     * @param CollectionFactory $blogCollection
     */
    public function __construct(
        CollectionFactory $blogCollection
    ) {
        $this->blogCollection = $blogCollection;
    }

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        $blogArr = [];
        $blogs = $this->blogCollection->create();

        foreach ($blogs as $blog) {
            $blogArr[] = ['value' => $blog->getBlogId(), 'label' => __($blog->getTitle())];
        }

        return $blogArr;
    }
}
