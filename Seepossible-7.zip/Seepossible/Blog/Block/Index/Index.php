<?php

/**
 * SeePossible
 * Copyright (C) 2020 Seepossible <info@seepossible.com>
 *
 * @package Seepossible_Blog
 * @copyright Copyright (c) 2020 Seepossible (http://www.seepossible.com/)
 * @license http://opensource.org/licenses/gpl-3.0.html GNU General Public License,version 3 (GPL-3.0)
 * @author SeePossible <info@seepossible.com>
 */

namespace Seepossible\Blog\Block\Index;

use Magento\Cms\Model\Template\FilterProvider;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\UrlInterface;
use Magento\Framework\View\Element\Template;
use Magento\Store\Model\ScopeInterface;
use Magento\Store\Model\StoreManagerInterface;
use Seepossible\Blog\Api\Data\BlogGroupInterface;
use Seepossible\Blog\Api\BlogGroupRepositoryInterface;
use Seepossible\Blog\Model\BlogGroupFactory;
use Seepossible\Blog\Model\ResourceModel\Blog\CollectionFactory;
use Seepossible\Blog\Model\ResourceModel\BlogGroup\Collection as BlogGroupCollection;
use Seepossible\Blog\Model\ResourceModel\BlogGroup\CollectionFactory as BlogGroupCollectionFactory;
use Seepossible\Blog\Model\Config\DefaultConfig;
use Seepossible\Blog\Helper\Data as HelperData;

use Magento\Framework\ObjectManagerInterface;



class Index extends Template
{

    protected $objectManager;


    /**
     * Default blog template
     * @var string
     */
    protected $_template = 'Seepossible_Blog::blog_main.phtml';

    /**
     * @var CollectionFactory
     */
    protected $blogCollectionFactory;

    /**
     * @var BlogGroupCollectionFactory
     */
    protected $blogGroupCollectionFactory;

    /**
     * @var BlogGroupFactory
     */
    protected $blogGroupFactory;

    /**
     * @var StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var HelperData
     */
    protected $customerSession;

    /**
     * @var ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var HelperData
     */
    protected $helper;

    /**
     * @var BlogGroupRepositoryInterface
     */
    protected $blogGroupRepository;

    /**
     * @var FilterProvider
     */
    protected $filterProvider;

    /**
     * Index constructor.
     *
     * @param Template\Context $context
     * @param CollectionFactory $blogCollectionFactory
     * @param BlogGroupRepositoryInterface $blogGroupRepository
     * @param BlogGroupCollectionFactory $blogGroupCollectionFactory
     * @param BlogGroupFactory $blogGroupFactory
     * @param FilterProvider $filterProvider
     * @param HelperData $helper
     */
    public function __construct(
        Template\Context $context,
        CollectionFactory $blogCollectionFactory,
        BlogGroupRepositoryInterface $blogGroupRepository,
        BlogGroupCollectionFactory $blogGroupCollectionFactory,
        BlogGroupFactory $blogGroupFactory,
        FilterProvider $filterProvider,
        ObjectManagerInterface $objectManager,
        HelperData $helper
    ) {
        $this->blogCollectionFactory = $blogCollectionFactory;
        $this->blogGroupCollectionFactory = $blogGroupCollectionFactory;
        $this->blogGroupRepository = $blogGroupRepository;
        $this->blogGroupFactory = $blogGroupFactory;
        $this->storeManager = $context->getStoreManager();
        $this->scopeConfig = $context->getScopeConfig();
        $this->helper = $helper;
        $this->filterProvider = $filterProvider;
        $this->objectManager = $objectManager;
        parent::__construct($context);
    }

    public function getBlogCollection()
    {

        $blogCollection = $this->blogCollectionFactory->create();
        return $blogCollection;
    }

    /**
     * Get blog group collection
     *
     * @return BlogGroupCollection
     * @throws NoSuchEntityException
     */
    public function getBlogGroupCollection()
    {
        $blogGroupCollection = $this->blogGroupCollectionFactory->create();
        $this->filterCollectionData($blogGroupCollection);
        return $blogGroupCollection;
    }

    /**
     * Filter collection data
     *
     * @param $collection
     * @throws NoSuchEntityException
     */
    private function filterCollectionData($collection)
    {
        $collection->addFieldToFilter('status', 1);
        $collection->addFieldToFilter(
            'customer_group',
            [
                ['null' => true],
                ['finset' => $this->helper->getCurrentCustomer()]
            ]
        );
        $collection->addFieldToFilter(
            'storeview',
            [
                ['eq' => 0],
                ['finset' => $this->getCurrentStore()]
            ]
        );
        $collection->setOrder('sortorder', 'ASC');
    }

    /**
     * Get group by id
     *
     * @param $groupId
     * @return BlogGroupInterface
     * @throws LocalizedException
     */
    public function getGroupById($groupId)
    {
        return $this->blogGroupRepository->getById($groupId);
    }

    /**
     * Filter blog content
     *
     * @param $string
     * @return string
     * @throws \Exception
     */
    public function filterOutputHtml($string)
    {
        return $this->filterProvider->getPageFilter()->filter($string);
    }

    /**
     * Get icon image url
     *
     * @param $icon
     * @return string
     * @throws NoSuchEntityException
     */
    public function getImageUrl($icon)
    {
        $mediaUrl = $this->storeManager
            ->getStore()
            ->getBaseUrl(UrlInterface::URL_TYPE_MEDIA);
        $imageUrl = $mediaUrl.'blog/tmp/icon/'.$icon;
        return $imageUrl;
    }

    /**
     * Get config value
     *
     * @param $config
     * @return mixed
     */
    public function getConfig($config)
    {
        return $this->scopeConfig->getValue(
            $config,
            ScopeInterface::SCOPE_STORE
        );
    }

    /**
     * Get current store id
     *
     * @return int
     * @throws NoSuchEntityException
     */
    public function getCurrentStore()
    {
        return $this->storeManager->getStore()->getId();
    }

    /**
     * Check is module enabled
     *
     * @return bool
     */
    public function isEnable()
    {
        return $this->getConfig(DefaultConfig::CONFIG_PATH_IS_ENABLE);
    }

    /**
     * Check is group enabled
     *
     * @return bool
     */
    public function isShowGroup()
    {
        if ($this->getShowGroup() != null) {
            return $this->helper->checkBlockData($this->getShowGroup());
        } else {
            return $this->getConfig(DefaultConfig::CONFIG_PATH_IS_SHOW_GROUP);
        }
    }

    /**
     * Check is group title enabled
     *
     * @return bool
     */
    public function isShowGroupTitle()
    {
        if ($this->getShowGroupTitle() != null) {
            return $this->helper->checkBlockData($this->getShowGroupTitle());
        } else {
            return $this->getConfig(DefaultConfig::CONFIG_PATH_IS_SHOW_GROUP_TITLE);
        }
    }

    /**
     * Get blog page type action
     *
     * @return string
     */
    public function getPageTypeAction()
    {
        if ($this->getPageType() == 'ajax') {
            $pageType = 'ajax';
        } elseif ($this->getPageType() == 'scroll') {
            $pageType = 'scroll';
        } else {
            $pageType = $this->getConfig(DefaultConfig::CONFIG_PATH_PAGE_TYPE);
        }
        return $pageType;
    }

    public function getMediaUrl(){

        $media_dir = $this->objectManager->get('Magento\Store\Model\StoreManagerInterface')
            ->getStore()
            ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);

        return $media_dir;
    }



}
